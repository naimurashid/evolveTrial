#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom Rcpp sourceCpp
#' @useDynLib evolveTrial, .registration = TRUE
## usethis namespace: end
NULL
